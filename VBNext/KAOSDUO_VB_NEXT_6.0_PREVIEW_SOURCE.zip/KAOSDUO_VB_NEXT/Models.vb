Imports System
Imports System.Collections.Generic

Public Class Actor
    Public X As Single
    Public Y As Single
    Public VX As Single
    Public VY As Single
    Public HP As Single
    Public Radius As Single = 18
    Public Cooldown As Single
    Public AttackTime As Single
    Public Kind As Integer
    Public IsBoss As Boolean
End Class

Public Class Shot
    Public X As Single
    Public Y As Single
    Public VX As Single
    Public VY As Single
    Public Life As Single
    Public Damage As Single
    Public Friendly As Boolean
    Public ColorId As Integer
    Public Pierce As Integer
End Class

Public Class Hazard
    Public X As Single
    Public Lane As Integer
    Public Kind As Integer
    Public Y As Single
    Public Radius As Single = 27
    Public Collected As Boolean
End Class

Public Class Spark
    Public X As Single
    Public Y As Single
    Public VX As Single
    Public VY As Single
    Public Life As Single
    Public MaxLife As Single
    Public ColorId As Integer
End Class

Public Class SaveData
    Public Property Schema As Integer = 1
    Public Property Character As String = "blue"
    Public Property Difficulty As Integer = 1
    Public Property Wave As Integer = 1
    Public Property HP As Single = 110
    Public Property Coins As Integer = 0
    Public Property Score As Integer = 0
    Public Property Unlocked As Boolean() = {True, False, False, False, False, False, False, False}
    Public Property Weapon As Integer = 0
    Public Property AbilityDash As Boolean = True
    Public Property AbilityDouble As Boolean = True
    Public Property AbilitySuper As Boolean = True
    Public Property AbilityOverdrive As Boolean = True
    Public Property PortalFailures As Integer = 0
End Class
