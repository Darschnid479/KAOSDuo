@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo  KAOSDUO VB NEXT - BUILD FOR WINDOWS
 echo ============================================
where dotnet >nul 2>nul
if errorlevel 1 (
 echo ERROR: Install the .NET 10 SDK from https://dotnet.microsoft.com/download/dotnet/10.0
 pause
 exit /b 1
)
dotnet --version
if not exist "publish" mkdir publish
dotnet publish "KAOSDUO.VBNext.vbproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish
if errorlevel 1 (
 echo BUILD FAILED. Copy the errors shown above.
 pause
 exit /b 1
)
echo.
echo READY: publish\KAOSDUO.VBNext.exe
echo Start the EXE from the publish folder. Assets are copied with it.
pause
