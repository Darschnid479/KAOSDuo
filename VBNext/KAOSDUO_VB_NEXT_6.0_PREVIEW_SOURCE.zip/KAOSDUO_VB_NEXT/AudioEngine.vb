Imports System
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text

Public Class AudioEngine
    <DllImport("winmm.dll", CharSet:=CharSet.Auto)>
    Private Shared Function mciSendString(command As String, buffer As StringBuilder, bufferSize As Integer, callback As IntPtr) As Integer
    End Function
    Private playing As Boolean
    Public Muted As Boolean = False
    Public Sub PlayCharacterMusic(character As String)
        StopMusic()
        If Muted Then Return
        Dim track = Path.Combine(AppContext.BaseDirectory, "Assets", If(character = "metal", "metal_theme.mp3", "blue_theme.mp3"))
        If Not File.Exists(track) Then Return
        Dim code = mciSendString("open """ & track & """ type mpegvideo alias kaosmusic", Nothing, 0, IntPtr.Zero)
        If code <> 0 Then Return
        mciSendString("setaudio kaosmusic volume to 800", Nothing, 0, IntPtr.Zero)
        mciSendString("play kaosmusic repeat", Nothing, 0, IntPtr.Zero)
        playing = True
    End Sub
    Public Sub Toggle(character As String)
        Muted = Not Muted
        If Muted Then StopMusic() Else PlayCharacterMusic(character)
    End Sub
    Public Sub StopMusic()
        If playing Then
            mciSendString("stop kaosmusic", Nothing, 0, IntPtr.Zero)
            mciSendString("close kaosmusic", Nothing, 0, IntPtr.Zero)
            playing = False
        End If
    End Sub
End Class
